//
//  UIScrollView+STRefresh.h
//  SwipeTableView
//
//  Created by Roy lee on 16/7/10.
//  Copyright © 2016年 Roy lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STRefreshHeader.h"

@interface UIScrollView (STRefresh)

@property (nonatomic, strong) STRefreshHeader * header;

@end
